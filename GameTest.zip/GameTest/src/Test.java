
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class Test extends GameObject {
    public static final int SIZE = 100;

    private final String door;
    private final String label;
    private boolean activated = false;

    public Test(float x, float y, int id,
                String door, String label) {
        super(x, y, id);
        this.door = door;
        this.label = label;
    }

    @Override
    public void tick(ArrayList<GameObject> objects) {
        if (activated || Game.currentRoom != 0
                || !"t1".equals(door)) {
            return;
        }

        Rectangle2D portalBounds =
            new Rectangle2D.Float(x, y, SIZE, SIZE);

        for (GameObject object : objects) {
            if (!(object instanceof Player)) {
                continue;
            }

            Player player = (Player) object;

            Rectangle2D playerBounds =
                new Rectangle2D.Float(
                    player.getX(), player.getY(),
                    Player.SIZE, Player.SIZE
                );

            if (portalBounds.intersects(playerBounds)) {
                activated = true;

                // Keep the existing player and its score.
                Game.p = player;
                player.setX((Game.WIDTH - Player.SIZE) / 2f);
                player.setY((Game.HEIGHT - Player.SIZE) / 2f);
                player.setVelX(0);
                player.setVelY(0);

                if (!player.inCombat()) {
                    player.toggleCombat();
                }

                // Game.render() handles spawning the enemies.
                Game.currentRoom = 1;
                return;
            }
        }
    }

    @Override
    public void render(Graphics g) {
        if (activated || Game.currentRoom != 0) {
            return;
        }

        Graphics drawing = g.create();
        try {
            drawing.setColor(new Color(100, 30, 180));
            drawing.fillOval((int) x, (int) y, SIZE, SIZE);

            drawing.setColor(Color.CYAN);
            drawing.drawOval((int) x, (int) y, SIZE, SIZE);

            drawing.setFont(new Font("SansSerif", Font.BOLD, 16));
            drawing.setColor(Color.WHITE);

            int textWidth =
                drawing.getFontMetrics().stringWidth(label);

            drawing.drawString(
                label,
                (int) x + (SIZE - textWidth) / 2,
                (int) y + SIZE / 2 + 6
            );
        } finally {
            drawing.dispose();
        }
    }
}